// Generate a single local HTML file. Runtime use requires no Node or network.
const fs=require('node:fs');
const path=require('node:path');
const esbuild=require('esbuild');
const root=path.resolve(__dirname,'..');
const mime={'.svg':'image/svg+xml','.png':'image/png','.ttf':'font/ttf','.woff2':'font/woff2','.woff':'font/woff'};
function dataURI(file){return `data:${mime[path.extname(file)]||'application/octet-stream'};base64,${fs.readFileSync(file).toString('base64')}`;}
function embedImages(html){return html.replace(/src="(assets\/[^\"]+)"/g,(match,rel)=>{const file=path.join(root,rel);return fs.existsSync(file)?`src="${dataURI(file)}"`:match;});}
const bundle=esbuild.buildSync({stdin:{contents:"import './script.js'; import './modules/interface.js'; import './modules/premium.js';",resolveDir:root},bundle:true,write:false,format:'iife',target:'es2022',charset:'utf8'}).outputFiles[0].text;
const styles=['style.css','interface.css','premium.css','sales-theme.css','assets/vendor/fontawesome/css/all.min.css'].map(rel=>{const file=path.join(root,rel);return fs.readFileSync(file,'utf8').replace(/url\(['"]?([^)'"\s]+)['"]?\)/g,(match,url)=>{const asset=path.resolve(path.dirname(file),url);return fs.existsSync(asset)&&fs.statSync(asset).isFile()?`url('${dataURI(asset)}')`:match;});}).join('\n');
let html=fs.readFileSync(path.join(root,'index.html'),'utf8').replace(/<link\b[^>]+>/g,'').replace(/<script\b[^>]*\bsrc=[^>]+><\/script>/g,'');
html=embedImages(html).replace('</head>',()=>`<link rel="icon" type="image/svg+xml" href="${dataURI(path.join(root,'assets/brand/logo.svg'))}"><link rel="apple-touch-icon" href="${dataURI(path.join(root,'assets/brand/apple-touch-icon.png'))}"><style>${styles}</style></head>`);
const pages={};for(const name of fs.readdirSync(path.join(root,'pages'))){if(name.endsWith('.html'))pages['pages/'+name]=embedImages(fs.readFileSync(path.join(root,'pages',name),'utf8'));}
const shim=`const smartStorePages=${JSON.stringify(pages).replace(/<\//g,'<\\/')};
const smartStoreFetch=window.fetch.bind(window);
window.fetch=(input, options)=>{const key=typeof input==='string'?input.replace(/^\\.\\//,''):'';if(Object.prototype.hasOwnProperty.call(smartStorePages,key))return Promise.resolve(new Response(smartStorePages[key],{status:200,headers:{'Content-Type':'text/html; charset=utf-8'}}));return smartStoreFetch(input,options);};\n`;
html=html.replace('</body>',()=>`<script>${(shim+bundle).replace(/<\/script/gi,'<\\/script')}</script></body>`);
fs.writeFileSync(path.join(root,'app.bundle.js'),`if (location.protocol === 'file:') {${shim}}\n` + bundle);
fs.writeFileSync(path.join(root,'SmartStore-Sales.html'),html);
process.stdout.write('Built app.bundle.js and SmartStore-Sales.html (all pages, fonts, icons and scripts embedded)\n');
