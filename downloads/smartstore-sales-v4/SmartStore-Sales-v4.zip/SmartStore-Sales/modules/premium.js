import { loadData, money, todayString, escapeHTML } from './storage.js';
import { notify } from './feedback.js';
const $ = selector => document.querySelector(selector);
const stockDialog = $('#stock-notifications');
const draftPages = new Set(['customers','debts','purchases','suppliers','expenses','employees','settings']);
function stocks() {
    const products=loadData('smartstore_products',[]);
    const out=products.filter(p=>Number(p.quantity)<=0);
    const low=products.filter(p=>Number(p.quantity)>0 && Number(p.quantity)<=Number(p.minQuantity ?? p.min_quantity ?? 5));
    const good=products.filter(p=>Number(p.quantity)>Number(p.minQuantity ?? p.min_quantity ?? 5));
    return {products,out,low,good};
}
function renderNotifications() {
    const {out,low}=stocks();
    const count=out.length+low.length;
    $('#notifications-btn').setAttribute('aria-label',`تنبيهات المخزون: ${count}`);
    const dot=$('#notifications-btn .notification-dot'); if(dot)dot.hidden=count===0;
    const list=$('#notification-list');list.replaceChildren();
    if (!count) {
        const empty=document.createElement('div');empty.className='calm-empty';empty.innerHTML='<i class="fa-solid fa-check" aria-hidden="true"></i><h3>المخزون مطمئن</h3><p>لا توجد منتجات وصلت إلى حد التنبيه.</p>';list.append(empty);return;
    }
    [...out,...low].forEach(product=>{
        const button=document.createElement('button');button.type='button';button.className='stock-notification';button.dataset.goPage='products';button.dataset.recordQuery=product.name || product.code || '';
        const name=document.createElement('strong');name.textContent=product.name || 'منتج بدون اسم';
        const details=document.createElement('small');details.textContent=`المتوفر ${Number(product.quantity)||0} · حد التنبيه ${Number(product.minQuantity ?? product.min_quantity ?? 5)}`;
        const tag=document.createElement('span');tag.className=`stock-pill ${Number(product.quantity)<=0?'out':'low'}`;tag.textContent=Number(product.quantity)<=0?'نافد':'منخفض';
        const info=document.createElement('span');info.append(name,details);button.append(info,tag);list.append(button);
    });
}
function renderChart() {
    const target=$('#sales-chart');if(!target)return;
    const count=Number($('#chart-period')?.value || 7);
    const dates=[];
    for(let i=count-1;i>=0;i--){const d=new Date();d.setHours(12,0,0,0);d.setDate(d.getDate()-i);dates.push(`${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`);}
    const sales=loadData('smartstore_sales',[]);
    const points=dates.map(date=>({date,total:sales.filter(s=>String(s.date || s.createdAt || '').slice(0,10)===date).reduce((sum,s)=>sum+(Number(s.total)||0),0)}));
    const total=points.reduce((sum,p)=>sum+p.total,0);
    const currency=localStorage.getItem('smartstore_currency')||'₪';
    $('#chart-total').textContent=money(total,currency);
    $('#chart-status').textContent=total?'المبالغ من الفواتير المحفوظة؛ مرّر على العمود أو ركّز عليه لعرض اليوم.':'لم تُسجّل مبيعات خلال الفترة. سيظهر المخطط عند حفظ أول فاتورة.';
    const max=Math.max(1,...points.map(p=>p.total));
    target.replaceChildren();target.style.setProperty('--bar-count',count);
    target.setAttribute('role','group');target.setAttribute('aria-label',`مبيعات آخر ${count} يومًا`);
    points.forEach((point,index)=>{
        const column=document.createElement('div');column.className='chart-column';column.tabIndex=0;
        const label=new Date(point.date+'T12:00:00').toLocaleDateString('ar',{month:'short',day:'numeric'});
        column.setAttribute('aria-label',`${label}: ${money(point.total,currency)}`);column.title=`${label}: ${money(point.total,currency)}`;
        const track=document.createElement('span');track.className='chart-track';
        const bar=document.createElement('span');bar.className='chart-bar';bar.style.height=point.total?Math.max(3,point.total/max*100)+'%':'2px';if(!point.total)bar.classList.add('zero');
        const tip=document.createElement('span');tip.className='bar-tip';tip.textContent=money(point.total,currency);track.append(bar,tip);
        const day=document.createElement('small');day.textContent=count===7?new Date(point.date+'T12:00:00').toLocaleDateString('ar',{weekday:'short'}):index%5===0?String(Number(point.date.slice(-2))):'';
        column.append(track,day);target.append(column);
    });
}
function renderStockOverview() {
    const ring=$('#stock-donut');if(!ring)return;
    const {products,out,low,good}=stocks();const total=products.length;
    const ready=total?good.length/total*100:0;const warn=total?low.length/total*100:0;
    ring.style.background=total?`conic-gradient(var(--petrol) 0 ${ready}%, var(--gold) ${ready}% ${ready+warn}%, var(--danger) ${ready+warn}% 100%)`:'var(--border)';
    $('#stock-ready').textContent=good.length;
    const legend=$('#stock-legend');legend.innerHTML=[['متوفر',good.length,'good'],['منخفض',low.length,'low'],['نافد',out.length,'out']].map(([label,count,status])=>`<div><span class="legend-dot ${status}"></span><span>${label}</span><strong>${count}</strong></div>`).join('');
    ring.setAttribute('aria-label',`من أصل ${total} منتج: ${good.length} متوفر، ${low.length} منخفض، ${out.length} نافد`);
}
function markDraft(page) {
    if(!draftPages.has(page))return;
    const section=$('#page-container .page-section');if(!section)return;
    const note=document.createElement('div');note.className='draft-notice';note.setAttribute('role','note');
    note.innerHTML='<i class="fa-solid fa-screwdriver-wrench" aria-hidden="true"></i><div><strong>هذا القسم قيد الاستكمال</strong><p>يعرض تصميم الواجهة فقط. الحفظ والأوامر في هذا القسم غير متاحة بعد؛ لم تُغيّر أي بيانات.</p></div>';
    section.prepend(note);
    section.querySelectorAll('form').forEach(form=>form.addEventListener('submit',event=>{event.preventDefault();notify('هذا القسم يحتاج استكمال برمجة وظائفه.','error');}));
    section.querySelectorAll('button').forEach(button=>{button.disabled=true;button.title='غير متاح في هذه النسخة';});
}
window.addEventListener('smartstore:page-loaded',event=>{renderChart();renderStockOverview();renderNotifications();markDraft(event.detail.page);});
window.addEventListener('smartstore:data-updated',()=>{renderNotifications();renderChart();renderStockOverview();});
window.addEventListener('storage',event=>{
    if(event.key?.startsWith('smartstore_')) {renderNotifications();renderChart();renderStockOverview();}
});
document.addEventListener('change',event=>{if(event.target.id==='chart-period')renderChart();});
document.addEventListener('click',event=>{
    if(event.target.closest('#notifications-btn,#dashboard-stock-alerts')){renderNotifications();stockDialog.showModal();}
    if(event.target.closest('.stock-close'))stockDialog.close();
});
stockDialog.addEventListener('click',event=>{if(event.target!==stockDialog)return;const r=stockDialog.getBoundingClientRect();if(event.clientX<r.left||event.clientX>r.right||event.clientY<r.top||event.clientY>r.bottom)stockDialog.close();});
document.querySelectorAll('.nav-item').forEach(link=>{
    if(draftPages.has(link.dataset.page)){link.title='واجهة قيد الاستكمال';const badge=document.createElement('small');badge.className='draft-nav-badge';badge.textContent='لاحقًا';link.append(badge);}
});
// Handle an already-rendered page if this module finished loading after the first request.
renderNotifications();renderChart();renderStockOverview();
window.addEventListener('smartstore:logout',()=>{
    stockDialog.close();document.body.classList.remove('navigation-open');
    $('#sidebar')?.classList.remove('is-open');$('#sidebar-overlay')?.classList.remove('is-visible');
    $('#mobile-menu-btn')?.setAttribute('aria-expanded','false');
});
