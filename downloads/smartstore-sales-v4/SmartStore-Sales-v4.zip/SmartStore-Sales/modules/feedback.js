let hideTimer;
export function notify(message, type = 'success') {
    const toast = document.querySelector('#toast');
    if (!toast) return;
    clearTimeout(hideTimer);
    toast.dataset.type = type;
    toast.hidden = false;
    toast.classList.add('visible');
    document.querySelector('#toast-message').textContent = message;
    const icon = document.querySelector('#toast-icon');
    if (icon) icon.className = type === 'error' ? 'fa-solid fa-circle-exclamation' : 'fa-solid fa-circle-check';
    hideTimer = setTimeout(() => { toast.hidden = true; toast.classList.remove('visible'); }, 5500);
}
