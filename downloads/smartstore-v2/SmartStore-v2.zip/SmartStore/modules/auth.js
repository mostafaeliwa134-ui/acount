
"use strict";

import { loadData, saveData } from "./storage.js";

const PROFILE_KEY = "smartstore_profile";
const SESSION_KEY = "smartstore_demo_session";
const ARABIC_PASSWORD = /\p{Script=Arabic}/u;
const PASSWORD_LANGUAGE_MESSAGE = "الحروف العربية غير مسموحة في كلمة المرور. بدّل لغة لوحة المفاتيح واكتب بالإنجليزية.";

function hasArabicPassword(value) {
    return ARABIC_PASSWORD.test(value || "");
}

function initializePasswordLanguage() {
    ["login-password", "register-password", "confirm-password"].forEach(id => {
        const field = getElement("#" + id);
        if (!field) return;
        field.dir = "ltr";
        field.setAttribute("autocapitalize", "none");
        field.setAttribute("spellcheck", "false");
        const message = getElement("#" + id + "-language");
        const showBlocked = () => { if (message) message.textContent = PASSWORD_LANGUAGE_MESSAGE; };
        field.addEventListener("beforeinput", event => {
            if (hasArabicPassword(event.data) && event.cancelable) {
                event.preventDefault();
                showBlocked();
            }
        });
        field.addEventListener("paste", event => {
            if (hasArabicPassword(event.clipboardData?.getData("text"))) {
                event.preventDefault();
                showBlocked();
            }
        });
        field.addEventListener("input", () => {
            const invalid = hasArabicPassword(field.value);
            field.setCustomValidity(invalid ? PASSWORD_LANGUAGE_MESSAGE : "");
            field.setAttribute("aria-invalid", String(invalid));
            if (message) message.textContent = invalid ? PASSWORD_LANGUAGE_MESSAGE : "";
        });
    });
}

// تشفير بسيط لكلمة المرور قبل الحفظ
function hashPassword(password) {
    return "utf8::" + btoa(Array.from(new TextEncoder().encode("ss_salt::" + password), byte => String.fromCharCode(byte)).join(""));
}

// قراءة عناصر الصفحة بأمان
function getElement(selector) {
    return document.querySelector(selector);
}

// عرض رسالة للمستخدم
function showAuthMessage(message, type = "error") {
    let messageElement = getElement("#auth-message");

    if (!messageElement) {
        messageElement = document.createElement("p");
        messageElement.id = "auth-message";
        messageElement.setAttribute("role", "status");

        const authCard = getElement("#auth-screen form:not([hidden])");

        if (authCard) {
            authCard.prepend(messageElement);
        } else {
            getElement("#auth-screen")?.prepend(messageElement);
        }
    }

    const visibleForm = getElement("#auth-screen form:not([hidden])");
    if (visibleForm && !visibleForm.contains(messageElement)) visibleForm.prepend(messageElement);
    messageElement.textContent = message;
    messageElement.dataset.type = type;
}

// الحصول على بيانات الحساب
export function getProfile() {
    return loadData(PROFILE_KEY, null);
}

// التحقق من وجود جلسة تجريبية
export function hasActiveSession() {
    try { return sessionStorage.getItem(SESSION_KEY) === "active"; }
    catch { return false; }
}

// إنشاء جلسة تجريبية
function startSession() {
    try { sessionStorage.setItem(SESSION_KEY, "active"); return true; }
    catch { showAuthMessage("المتصفح يمنع حفظ الجلسة. اسمح بتخزين بيانات الموقع أو افتح النسخة في متصفح عادي."); return false; }
}

// تسجيل الدخول التجريبي
function handleLogin(event) {
    event.preventDefault();

    const email = getElement("#login-email")?.value.trim();
    const password = getElement("#login-password")?.value;

    if (!email || !password) {
        showAuthMessage("يرجى إدخال البريد الإلكتروني وكلمة المرور.");
        return;
    }

    if (hasArabicPassword(password)) { showAuthMessage(PASSWORD_LANGUAGE_MESSAGE); return; }

    const profile = getProfile();

    if (!profile || profile.email?.toLowerCase() !== email.toLowerCase()) {
        showAuthMessage("ما لقينا هذا الحساب هنا. إذا هذه أول زيارة، اضغط «إنشاء حساب جديد». الحسابات محفوظة في نفس المتصفح ومكان فتح النسخة فقط.");
        return;
    }

    // دعم كلمات المرور القديمة (نص عادي) والجديدة (مشفرة)
    const isHashedMatch = profile.password === hashPassword(password);
    let isLegacyMatch = false;
    try { isLegacyMatch = profile.password === btoa("ss_salt::" + password); } catch {}
    const isPlainMatch = profile.password === password;

    if (!isHashedMatch && !isPlainMatch && !isLegacyMatch) {
        showAuthMessage("كلمة المرور غير صحيحة.");
        return;
    }

    // ترقية الحساب القديم تلقائياً إلى كلمة مرور مشفرة
    if (!isHashedMatch && (isPlainMatch || isLegacyMatch)) {
        saveData(PROFILE_KEY, { ...profile, password: hashPassword(password) });
    }

    if (!startSession()) return;
    showAuthMessage("تم تسجيل الدخول بنجاح.", "success");

    window.dispatchEvent(new CustomEvent("smartstore:login", {
        detail: { profile }
    }));
}

// إنشاء حساب تجريبي
function handleRegister(event) {
    event.preventDefault();

    const ownerName = getElement("#owner-name")?.value.trim();
    const storeName = getElement("#store-name")?.value.trim();
    const email = getElement("#register-email")?.value.trim();
    const phone = getElement("#register-phone")?.value.trim();
    const password = getElement("#register-password")?.value;
    const confirmPassword = getElement("#confirm-password")?.value;

    if (!ownerName || !storeName || !email || !password || !confirmPassword) {
        showAuthMessage("يرجى تعبئة جميع الحقول المطلوبة.");
        return;
    }

    if (hasArabicPassword(password) || hasArabicPassword(confirmPassword)) {
        showAuthMessage(PASSWORD_LANGUAGE_MESSAGE);
        return;
    }

    if (password.length < 8) {
        showAuthMessage("يجب أن تتكون كلمة المرور من 8 أحرف على الأقل.");
        return;
    }

    if (password !== confirmPassword) {
        showAuthMessage("كلمتا المرور غير متطابقتين.");
        return;
    }

    const existingProfile = getProfile();

    if (existingProfile) {
        showAuthMessage("يوجد حساب محفوظ على هذا المتصفح. سجّل الدخول إليه، وعدّل البريد من الملف الشخصي بدل استبدال الحساب.");
        return;
    }

    const profile = {
        ownerName,
        storeName,
        email,
        phone,
        password: hashPassword(password),
        createdAt: new Date().toISOString()
    };

    if (!saveData(PROFILE_KEY, profile)) {
        showAuthMessage("تعذر حفظ الحساب. تحقق من مساحة التخزين في المتصفح.");
        return;
    }

    if (!startSession()) return;

    showAuthMessage("تم إنشاء الحساب بنجاح.", "success");

    window.dispatchEvent(new CustomEvent("smartstore:login", {
        detail: { profile }
    }));
}

// تسجيل الخروج
export function logout() {
    try { sessionStorage.removeItem(SESSION_KEY); } catch {}
    setAuthView(false);

    window.dispatchEvent(new CustomEvent("smartstore:logout"));
}

// تهيئة أحداث تسجيل الدخول والتسجيل
export function initializeAuth() {
    initializePasswordLanguage();
    const loginForm = getElement("#login-form");
    const registerForm = getElement("#register-form");

    loginForm?.addEventListener("submit", handleLogin);
    registerForm?.addEventListener("submit", handleRegister);

    getElement("#logout-btn")?.addEventListener("click", logout);
    getElement("#dropdown-logout-btn")?.addEventListener("click", logout);

    // إظهار/إخفاء كلمة المرور عند الضغط على زر العين
    document.addEventListener("click", (event) => {
        const toggleBtn = event.target.closest(".password-toggle");

        if (!toggleBtn) return;

        const inputId = toggleBtn.dataset.password;
        const input = getElement(`#${inputId}`);

        if (!input) return;

        const isHidden = input.type === "password";

        input.type = isHidden ? "text" : "password";

        const icon = toggleBtn.querySelector("i");

        if (icon) {
            icon.className = isHidden
                ? "fa-regular fa-eye-slash"
                : "fa-regular fa-eye";
        }

        toggleBtn.setAttribute(
            "aria-label",
            isHidden ? "إخفاء كلمة المرور" : "إظهار كلمة المرور"
        );
    });

    getElement("#auth-switch-button")?.addEventListener("click", () => setAuthView(Boolean(getElement("#register-form")?.hidden)));
}

function setAuthView(showRegister) {
        const loginForm = getElement("#login-form");
        const registerForm = getElement("#register-form");

        if (!loginForm || !registerForm) {
            return;
        }


        loginForm.hidden = showRegister;
        registerForm.hidden = !showRegister;

        const title = getElement("#auth-title");
        const description = getElement("#auth-description");

        if (title) {
            title.textContent = showRegister ? "إنشاء حساب جديد" : "تسجيل الدخول";
        }

        if (description) {
            description.textContent = showRegister
                ? "أنشئ حسابك وابدأ بإدارة متجرك."
                : "سجّل الدخول للمتابعة إلى متجرك.";
        }

        const button = getElement("#auth-switch-button");

        if (button) {
            button.textContent = showRegister
                ? "لديك حساب؟ سجّل الدخول"
                : "ليس لديك حساب؟ أنشئ حسابًا";
        }

        const switchText = getElement("#auth-switch-text");

        if (switchText) {
            switchText.textContent = showRegister
                ? "لديك حساب بالفعل؟"
                : "ليس لديك حساب؟";
        }

        const message = getElement("#auth-message");

        if (message) {
            message.remove();
        }
}
