import { loadData, money } from './storage.js';
import { loadPage } from './navigation.js';

const input = document.querySelector('#global-search');
const results = document.querySelector('#page-search-results');
const help = document.querySelector('#usage-help');
const links = [...document.querySelectorAll('.nav-item[data-page]')];

function closeSearch() {
    results.hidden = true;
    input.setAttribute('aria-expanded', 'false');
}
function showPages() {
    const query = input.value.trim().toLocaleLowerCase('ar');
    results.replaceChildren();
    const addGroup = (title, items) => {
        if (!items.length) return;
        const heading = document.createElement('p'); heading.className='search-group-title'; heading.textContent=title; results.append(heading);
        items.slice(0,6).forEach(item => {
            const button = document.createElement('button'); button.type='button'; button.dataset.goPage=item.page;
            if (item.query !== undefined) button.dataset.recordQuery=item.query;
            const label=document.createElement('strong'); label.textContent=item.label; button.append(label);
            if (item.detail) {const detail=document.createElement('small');detail.textContent=item.detail;button.append(detail);}
            results.append(button);
        });
    };
    if (query) {
        const currency=localStorage.getItem('smartstore_currency') || '₪';
        addGroup('المنتجات', loadData('smartstore_products',[]).filter(product=>`${product.name || ''} ${product.code || ''}`.toLocaleLowerCase('ar').includes(query)).map(product=>({page:'products',query:product.name || product.code || '',label:product.name || 'منتج',detail:`${product.code || 'بدون رمز'} · ${money(product.sellPrice,currency)} · المتوفر ${Number(product.quantity)||0}`})));
        addGroup('الفواتير', loadData('smartstore_sales',[]).filter(sale=>`${sale.invoice || sale.id || ''} ${sale.customerName || sale.customer || ''}`.toLocaleLowerCase('ar').includes(query)).map(sale=>({page:'sales',query:sale.invoice || sale.id || '',label:sale.invoice || sale.id || 'فاتورة',detail:`${sale.customerName || sale.customer || 'عميل نقدي'} · ${money(sale.total,currency)}`})));
    }
    addGroup('الصفحات',links.filter(link=>link.textContent.toLocaleLowerCase('ar').includes(query)).map(link=>({page:link.dataset.page,label:link.textContent.trim()})));
    if (!results.querySelector('button')) {
        const empty=document.createElement('p');empty.textContent='لا توجد نتائج. جرّب اسم المنتج أو رمز الفاتورة أو اسم الصفحة.';results.append(empty);
    }
    results.hidden=false;input.setAttribute('aria-expanded','true');
}
input.addEventListener('input', showPages);
input.addEventListener('focus', showPages);
input.addEventListener('keydown', event => {
    if (event.key === 'ArrowDown') {
        event.preventDefault();
        results.querySelector('button')?.focus();
    }
    if (event.key === 'Enter') {
        event.preventDefault();
        results.querySelector('button')?.click();
    }
});
results.addEventListener('keydown', event => {
    const buttons = [...results.querySelectorAll('button')];
    const index = buttons.indexOf(document.activeElement);
    if (event.key === 'ArrowDown' || event.key === 'ArrowUp') {
        event.preventDefault();
        const direction = event.key === 'ArrowDown' ? 1 : -1;
        buttons[(index + direction + buttons.length) % buttons.length]?.focus();
    }
});
document.addEventListener('click', async event => {
    if (!event.target.closest('.search-wrapper')) closeSearch();
    const shortcut = event.target.closest('[data-go-page]');
    if (shortcut) {
        closeSearch();
        input.value = '';
        const loaded = await loadPage(shortcut.dataset.goPage);
        if (!loaded) return;
        if (shortcut.dataset.recordQuery !== undefined) {
            const field = document.querySelector(shortcut.dataset.goPage === 'products' ? '#product-search' : '#sales-search');
            if (field) { field.value=shortcut.dataset.recordQuery; field.dispatchEvent(new Event('input',{bubbles:true})); }
        }
        document.querySelector('#stock-notifications')?.close();
        document.querySelector('#page-container').focus({preventScroll: true});
        window.scrollTo({top:0,behavior:'instant'});
    }
    if (event.target.closest('#add-product-btn')) {
        document.querySelector('#product-name')?.focus();
        document.querySelector('#product-form')?.scrollIntoView({block:'center',behavior:'smooth'});
    }
    if (event.target.closest('#open-help')) help.showModal();
    if (event.target.closest('.help-close, .help-done')) help.close();
    if (event.target === help) {
        const rect = help.getBoundingClientRect();
        if (event.clientX < rect.left || event.clientX > rect.right || event.clientY < rect.top || event.clientY > rect.bottom) help.close();
    }
});
document.addEventListener('keydown', event => {
    if ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === 'k' && !document.querySelector('#app-screen').hidden) {
        event.preventDefault(); input.focus();
    }
    if (event.key === 'Escape') closeSearch();
});
document.addEventListener('focusin', event => {
    if (!event.target.closest('.search-wrapper')) closeSearch();
});
// Make field intent clear on phone keyboards as well as desktop.
document.querySelectorAll('input[type=email]').forEach(field => field.dir = 'ltr');
window.addEventListener('smartstore:page-loaded', () => {
    document.querySelectorAll('#page-container input[type=email], #page-container input[type=tel], #page-container input[type=number]').forEach(field => field.dir = 'ltr');
    document.querySelectorAll('#page-container input[required], #page-container select[required]').forEach(field => {
        const label = document.querySelector(`label[for="${field.id}"]`);
        if (label && !label.querySelector('.required-label')) {
            label.textContent = label.textContent.replace(/\*/g, '').trim();
            const badge = document.createElement('span');
            badge.className = 'required-label'; badge.textContent = 'مطلوب';
            label.append(badge);
        }
    });
});

// Theme works on login and all application pages; storage failure does not block it.
function updateThemeButtons() {
    const dark = document.documentElement.dataset.theme === 'dark';
    document.querySelectorAll('.theme-toggle').forEach(button => {
        button.setAttribute('aria-label', dark ? 'تفعيل الوضع الفاتح' : 'تفعيل الوضع الداكن');
        button.setAttribute('aria-pressed', String(dark));
        button.title = dark ? 'الوضع الفاتح' : 'الوضع الداكن';
        button.querySelector('i').className = dark ? 'fa-solid fa-sun' : 'fa-solid fa-moon';
    });
    document.querySelector('meta[name="theme-color"]').content = dark ? '#101b2f' : '#f4f7fc';
}
updateThemeButtons();
document.querySelectorAll('.theme-toggle').forEach(button => button.addEventListener('click', () => {
    const theme = document.documentElement.dataset.theme === 'dark' ? 'light' : 'dark';
    document.documentElement.dataset.theme = theme;
    try { localStorage.setItem('smartstore_theme', theme); } catch {}
    updateThemeButtons();
}));
matchMedia('(prefers-color-scheme: dark)').addEventListener('change', event => {
    try { if (localStorage.getItem('smartstore_theme')) return; } catch {}
    document.documentElement.dataset.theme = event.matches ? 'dark' : 'light';
    updateThemeButtons();
});

const infoDialog = document.querySelector('#site-information');
document.addEventListener('click', async event => {
    const trigger = event.target.closest('[data-info-page]');
    if (trigger) {
        const key = trigger.dataset.infoPage;
        if (!['about', 'privacy'].includes(key)) return;
        const container = document.querySelector('#site-information-content');
        container.textContent = 'جارٍ تحميل المعلومات…';
        infoDialog.showModal();
        try {
            const response = await fetch(`pages/${key}.html`);
            if (!response.ok) throw new Error('Page unavailable');
            container.innerHTML = await response.text();
        } catch {
            container.textContent = 'تعذر تحميل المعلومات. حاول مجددًا.';
        }
    }
    if (event.target.closest('.info-close')) infoDialog.close();
    if (event.target.closest('#footer-help')) help.showModal();
});
infoDialog.addEventListener('click', event => {
    if (event.target !== infoDialog) return;
    const rect = infoDialog.getBoundingClientRect();
    if (event.clientX < rect.left || event.clientX > rect.right || event.clientY < rect.top || event.clientY > rect.bottom) infoDialog.close();
});
