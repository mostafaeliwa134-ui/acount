
"use strict";

// قراءة البيانات المحفوظة محليًا
export function loadData(key, defaultValue = []) {
    try {
        const savedData = pendingRecovery && Object.hasOwn(pendingRecovery,key) ? pendingRecovery[key] : localStorage.getItem(key);

        if (savedData === null) {
            return defaultValue;
        }

        return JSON.parse(savedData);
    } catch (error) {
        console.error(`خطأ في قراءة البيانات (${key}):`, error);
        return defaultValue;
    }
}

// حفظ البيانات محليًا
export function saveData(key, data) {
    if (!recoverPendingTransaction()) return false;
    try {
        localStorage.setItem(key, JSON.stringify(data));
        return true;
    } catch (error) {
        console.error(`خطأ في حفظ البيانات (${key}):`, error);
        return false;
    }
}

// إنشاء معرّف فريد
export function createId() {
    if (typeof crypto !== "undefined" && crypto.randomUUID) {
        return crypto.randomUUID();
    }

    return `${Date.now()}-${Math.random().toString(36).slice(2, 11)}`;
}

// تنسيق المبالغ المالية
export function money(amount, currency = "₪") {
    const value = Number(amount) || 0;

    return `${value.toLocaleString("en-US", {
        minimumFractionDigits: 2,
        maximumFractionDigits: 2
    })} ${currency}`;
}

// حماية النصوص قبل عرضها داخل HTML
export function escapeHTML(value) {
    return String(value ?? "").replace(/[&<>"']/g, character => {
        const entities = {
            "&": "&amp;",
            "<": "&lt;",
            ">": "&gt;",
            '"': "&quot;",
            "'": "&#039;"
        };

        return entities[character];
    });
}

// إرجاع تاريخ اليوم بصيغة YYYY-MM-DD
export function todayString() {
    const now = new Date();
    const year = now.getFullYear();
    const month = String(now.getMonth() + 1).padStart(2, "0");
    const day = String(now.getDate()).padStart(2, "0");

    return `${year}-${month}-${day}`;
}

// Journal multi-key operations so a failed purchase/sale/settings save can be rolled back.
const JOURNAL_KEY = 'smartstore_pending_transaction_v1';
let pendingRecovery = null;
export function recoverPendingTransaction() {
    try {
        const raw=localStorage.getItem(JOURNAL_KEY);
        if (!raw) { pendingRecovery=null; return true; }
        const journal=JSON.parse(raw);
        if (!journal || typeof journal.before!=='object' || Array.isArray(journal.before)) throw new Error('Invalid recovery journal');
        pendingRecovery=journal.before;
        for (const [key,value] of Object.entries(journal.before)) {
            if (!key.startsWith('smartstore_') || key===JOURNAL_KEY || (value!==null && typeof value!=='string')) throw new Error('Invalid recovery entry');
        }
        for (const [key,value] of Object.entries(journal.before)) value===null?localStorage.removeItem(key):localStorage.setItem(key,value);
        localStorage.removeItem(JOURNAL_KEY);pendingRecovery=null;return true;
    } catch { return false; }
}
export function commitData(changes) {
    if (!recoverPendingTransaction()) return false;
    const before={};
    try {
        const entries=Object.entries(changes).map(([key,value])=>{
            if (!key.startsWith('smartstore_') || key===JOURNAL_KEY) throw new Error('Invalid storage key');
            before[key]=localStorage.getItem(key);
            return [key,key==='smartstore_currency'?String(value):JSON.stringify(value)];
        });
        localStorage.setItem(JOURNAL_KEY,JSON.stringify({before}));
        for(const [key,value] of entries)localStorage.setItem(key,value);
        localStorage.removeItem(JOURNAL_KEY);
        window.dispatchEvent(new CustomEvent('smartstore:data-updated'));
        return true;
    } catch {
        pendingRecovery=before;
        try {
            for(const [key,value] of Object.entries(before))value===null?localStorage.removeItem(key):localStorage.setItem(key,value);
            localStorage.removeItem(JOURNAL_KEY);pendingRecovery=null;
        } catch {}
        return false;
    }
}
recoverPendingTransaction();
