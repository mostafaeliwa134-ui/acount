
"use strict";

const $ = (selector, parent = document) =>
    parent.querySelector(selector);

const $$ = (selector, parent = document) =>
    [...parent.querySelectorAll(selector)];

const pageInfo = {
    about: { title: "من نحن", subtitle: "تعرّف على سمارت ستور وطريقة العمل." },
    privacy: { title: "الخصوصية والبيانات", subtitle: "معلومات واضحة عن تخزين بياناتك واستخدامها." },
    dashboard: {
        title: "لوحة التحكم",
        subtitle: "نظرة عامة على أداء متجرك."
    },
    products: {
        title: "المنتجات",
        subtitle: "إدارة المنتجات والأسعار والكميات."
    },
    sales: {
        title: "المبيعات",
        subtitle: "متابعة فواتير وعمليات البيع."
    },
    customers: {
        title: "العملاء",
        subtitle: "إدارة بيانات العملاء."
    },
    debts: {
        title: "الديون",
        subtitle: "متابعة المبالغ المستحقة والمدفوعات."
    },
    inventory: {
        title: "المخزون",
        subtitle: "متابعة الكميات وحالة المخزون."
    },
    purchases: {
        title: "المشتريات",
        subtitle: "متابعة مشتريات المتجر."
    },
    suppliers: {
        title: "الموردون",
        subtitle: "إدارة بيانات الموردين."
    },
    expenses: {
        title: "المصروفات",
        subtitle: "تسجيل ومتابعة مصروفات المتجر."
    },
    reports: {
        title: "التقارير",
        subtitle: "مراجعة الأداء المالي والتشغيلي."
    },
    employees: {
        title: "الموظفون",
        subtitle: "بيانات فريق العمل والوظائف والرواتب."
    },
    profile: {
        title: "الملف الشخصي",
        subtitle: "عرض بيانات حسابك."
    },
    settings: {
        title: "الإعدادات",
        subtitle: "تخصيص إعدادات المتجر."
    }
};

let currentPage = null;

export function getCurrentPage() {
    return currentPage;
}

// تحميل صفحة HTML داخل الحاوية الرئيسية
let navigationSequence = 0;
let lastRequestedPage = 'dashboard';
export async function loadPage(pageName) {
    const pageContainer = $('#page-container');
    if (!pageContainer || !Object.hasOwn(pageInfo, pageName)) return false;
    const sequence = ++navigationSequence;
    lastRequestedPage = pageName;
    pageContainer.setAttribute('aria-busy','true');
    pageContainer.innerHTML = `<div class="loading-state" role="status"><span class="loader-ring"></span><strong>جارٍ تجهيز مساحة العمل</strong><p>لحظات ونرتّب المعلومات أمامك.</p></div>`;
    try {
        const response = await fetch(`pages/${pageName}.html`);
        if (!response.ok) throw new Error('Page unavailable');
        const html = await response.text();
        if (sequence !== navigationSequence) return false;
        pageContainer.innerHTML = html;
        currentPage = pageName;
        updatePageHeading(pageName);
        updateActiveNavigation(pageName);
        window.dispatchEvent(new CustomEvent('smartstore:page-loaded', {detail:{page:pageName}}));
        return true;
    } catch {
        if (sequence !== navigationSequence) return false;
        pageContainer.innerHTML = `<div class="error-state" role="alert"><i class="fa-solid fa-wifi" aria-hidden="true"></i><h2>تعذر فتح الصفحة</h2><p>تأكد من تشغيل المشروع أو افتح ملف المعاينة الموحّد، ثم أعد المحاولة.</p><button type="button" class="btn btn-primary" id="retry-navigation">إعادة المحاولة</button></div>`;
        return false;
    } finally {
        if (sequence === navigationSequence) pageContainer.setAttribute('aria-busy','false');
    }
}

// تحديث عنوان الصفحة
function updatePageHeading(pageName) {
    const info = pageInfo[pageName];

    const title = $("#page-title");
    const heading = $("#page-heading-title");
    const breadcrumb = $("#page-breadcrumb");
    const subtitle = $("#page-subtitle");

    if (title) title.textContent = info.title;
    if (heading) heading.textContent = info.title;
    if (breadcrumb) breadcrumb.textContent = info.title;
    if (subtitle) subtitle.textContent = info.subtitle;
}

// تحديد الصفحة النشطة في القائمة الجانبية
function updateActiveNavigation(pageName) {
    $$(".nav-item[data-page]").forEach((item) => {
        const isActive = item.dataset.page === pageName;

        item.classList.toggle("active", isActive);

        if (isActive) {
            item.setAttribute("aria-current", "page");
        } else {
            item.removeAttribute("aria-current");
        }
    });
}

// إغلاق القائمة الجانبية على الشاشات الصغيرة
function closeSidebar() {
    $("#mobile-menu-btn")?.setAttribute("aria-expanded", "false");
    document.body.classList.remove("navigation-open");
    $("#sidebar")?.classList.remove("is-open");
    $("#sidebar-overlay")?.classList.remove("is-visible");
}

// إغلاق قائمة البروفايل المنسدلة
function closeProfileDropdown() {
    const dropdown = $("#profile-dropdown");
    const btn = $("#profile-menu-btn");

    if (dropdown) dropdown.hidden = true;
    if (btn) btn.setAttribute("aria-expanded", "false");
}

// تجهيز أحداث التنقل
export function initializeNavigation() {
    document.addEventListener("keydown", (event) => {
        if (event.key === "Escape") { closeSidebar(); closeProfileDropdown(); }
    });
    document.addEventListener("click", (event) => {
        if (event.target.closest("#retry-navigation")) { loadPage(lastRequestedPage); return; }
        const navItem = event.target.closest(".nav-item[data-page]");

        if (navItem) {
            event.preventDefault();

            const pageName = navItem.dataset.page;

            loadPage(pageName);
            closeSidebar();
            closeProfileDropdown();
            return;
        }

        // عناصر القائمة المنسدلة للبروفايل
        const dropdownItem = event.target.closest(".profile-dropdown-item[data-page]");

        if (dropdownItem) {
            const pageName = dropdownItem.dataset.page;

            loadPage(pageName);
            closeProfileDropdown();
            return;
        }

        // فتح/إغلاق قائمة البروفايل
        if (event.target.closest("#profile-menu-btn")) {
            const dropdown = $("#profile-dropdown");
            const btn = $("#profile-menu-btn");

            if (!dropdown) return;

            const isOpen = !dropdown.hidden;

            dropdown.hidden = isOpen;
            btn?.setAttribute("aria-expanded", String(!isOpen));
            return;
        }

        // إغلاق قائمة البروفايل عند النقر خارجها
        if (!event.target.closest(".profile-menu-wrapper")) {
            closeProfileDropdown();
        }

        if (event.target.closest("#mobile-menu-btn")) {
            $("#sidebar")?.classList.add("is-open");
            $("#mobile-menu-btn")?.setAttribute("aria-expanded", "true");
            document.body.classList.add("navigation-open");
            $("#sidebar-overlay")?.classList.add("is-visible");
            return;
        }

        if (
            event.target.closest("#sidebar-close-btn") ||
            event.target.closest("#sidebar-overlay")
        ) {
            closeSidebar();
        }
    });

    // فتح لوحة التحكم أولًا
    loadPage("dashboard");
}
