let hideTimer;
export function notify(message, type = 'success') {
    const toast = document.querySelector('#toast');
    if (!toast) return;
    clearTimeout(hideTimer);
    toast.dataset.type = type;
    toast.hidden = false;
    toast.classList.add('visible');
    document.querySelector('#toast-message').textContent = message;
    const icon = document.querySelector('#toast-icon');
    if (icon) icon.className = type === 'error' ? 'fa-solid fa-circle-exclamation' : 'fa-solid fa-circle-check';
    hideTimer = setTimeout(() => { toast.hidden = true; toast.classList.remove('visible'); }, 5500);
}

// In-page confirmation also works in browsers that suppress native JavaScript dialogs.
export function confirmAction(message) {
    let dialog=document.querySelector('#action-confirmation');
    if(!dialog){
        dialog=document.createElement('dialog');dialog.id='action-confirmation';dialog.className='usage-help';dialog.setAttribute('aria-labelledby','action-confirmation-title');
        dialog.innerHTML='<h2 id="action-confirmation-title">تأكيد العملية</h2><p class="dialog-description" id="action-confirmation-message"></p><div class="confirmation-actions"><button type="button" class="btn btn-secondary" data-confirm-no>إلغاء</button><button type="button" class="btn btn-primary" data-confirm-yes>تأكيد</button></div>';
        document.body.append(dialog);
    }
    if(dialog.open)return Promise.resolve(false);
    dialog.querySelector('#action-confirmation-message').textContent=message;
    return new Promise(resolve=>{
        let done=false;
        const finish=answer=>{if(done)return;done=true;dialog.querySelector('[data-confirm-yes]').onclick=null;dialog.querySelector('[data-confirm-no]').onclick=null;dialog.oncancel=null;dialog.close();resolve(answer);};
        dialog.querySelector('[data-confirm-yes]').onclick=()=>finish(true);
        dialog.querySelector('[data-confirm-no]').onclick=()=>finish(false);
        dialog.oncancel=event=>{event.preventDefault();finish(false);};dialog.showModal();dialog.querySelector('[data-confirm-no]').focus();
    });
}
