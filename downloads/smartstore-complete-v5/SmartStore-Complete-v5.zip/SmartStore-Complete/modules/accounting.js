import {loadData} from './storage.js';
export function cents(value) {
    const number=Number(value);
    if(!Number.isFinite(number)||number<0||number>1000000000)throw new Error('أدخل مبلغًا صحيحًا غير سالب لا يتجاوز مليارًا.');
    return Math.round((number+Number.EPSILON)*100);
}
export function receiptTotals(record, type='sale') {
    const total=cents(record.total||0);
    const fallback=record.debt===undefined?total:Math.max(0,total-cents(record.debt));
    const initial=Math.min(total,cents(record.initialAmountPaid ?? record.amountPaid ?? (fallback/100)));
    const payments=loadData(type==='sale'?'smartstore_debt_payments':'smartstore_supplier_payments',[]).filter(p=>String(p[type==='sale'?'saleId':'purchaseId'])===String(record.id));
    const collected=payments.reduce((sum,p)=>sum+cents(p.amount||0),0);
    return {total,initial,collected,paid:Math.min(total,initial+collected),remaining:Math.max(0,total-initial-collected)};
}
export function stockMinimum(product) {
    return Number(product.minQuantity ?? product.min_quantity ?? loadData('smartstore_settings',{}).lowStock ?? 5);
}
export function validDate(value) {
    if(!/^\d{4}-\d{2}-\d{2}$/.test(value))return false;
    const d=new Date(value+'T12:00:00Z');return Number.isFinite(d.getTime())&&d.toISOString().slice(0,10)===value;
}
