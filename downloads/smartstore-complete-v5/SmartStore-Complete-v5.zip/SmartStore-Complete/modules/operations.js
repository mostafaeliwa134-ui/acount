import {loadData,commitData,createId,money,escapeHTML as esc,todayString,recoverPendingTransaction} from './storage.js';
import {cents,receiptTotals,validDate,stockMinimum} from './accounting.js';
import {notify,confirmAction} from './feedback.js';
import {updateProfileUI} from './profile.js';
const $=selector=>document.querySelector(selector);
const KEY=name=>'smartstore_'+name;
const list=name=>loadData(KEY(name),[]);
const value=id=>$('#'+id)?.value.trim()||'';
const currency=()=>localStorage.getItem(KEY('currency'))||'₪';
const cash=amount=>esc(money(amount,currency()));
const same=(a,b)=>String(a)===String(b);
let purchaseItems=[];
let activePurchase='';
const expenseLabels={rent:'الإيجار',utilities:'الكهرباء والمياه',transport:'المواصلات',salaries:'الرواتب',maintenance:'الصيانة',other:'أخرى'};
const configs={
 customer:{page:'customers',key:'customers',label:'العميل',search:'customers-search',table:'customers-table',fields:['name','phone','email','address','notes'],required:['name']},
 supplier:{page:'suppliers',key:'suppliers',label:'المورد',search:'suppliers-search',table:'suppliers-table',fields:['name','phone','email','company','address','notes'],required:['name']},
 expense:{page:'expenses',key:'expenses',label:'المصروف',search:'expenses-search',table:'expenses-table',fields:['title','category','amount','date','payment-method','notes'],required:['title','category','amount','date']},
 employee:{page:'employees',key:'employees',label:'الموظف',search:'employees-search',table:'employees-table',fields:['name','phone','email','role','salary','start-date','status'],required:['name','role']}
};
function save(changes,message) {
    if(!commitData(changes))throw new Error('تعذر الحفظ. لم تكتمل العملية؛ تحقق من مساحة التخزين أو سماح المتصفح بحفظ البيانات.');
    if(message)notify(message);
}
function actions(type,id) {return `<button type="button" data-edit-record="${type}" data-record-id="${esc(id)}">تعديل</button><button type="button" data-delete-record="${type}" data-record-id="${esc(id)}">حذف</button>`;}
function customerSales(record) {return list('sales').filter(s=>same(s.customerId,record.id)||(!s.customerId&&(s.customerName||s.customer)===record.name));}
function supplierPurchases(record) {return list('purchases').filter(p=>same(p.supplierId??p.supplier,record.id));}
function renderDirectory(type) {
    const c=configs[type],tbody=$('#'+c.table);if(!tbody)return;
    const query=value(c.search).toLocaleLowerCase('ar');
    const filter=type==='employee'?value('employees-status-filter'):type==='expense'?value('expenses-category-filter'):'';
    const from=type==='expense'?value('expenses-from'):'';const to=type==='expense'?value('expenses-to'):'';
    const rows=list(c.key).filter(r=>Object.values(r).join(' ').toLocaleLowerCase('ar').includes(query)&&(!filter||(type==='employee'?r.status:r.category)===filter)&&(!from||r.date>=from)&&(!to||r.date<=to));
    const cols={customer:7,supplier:7,expense:6,employee:6}[type];
    tbody.innerHTML=rows.length?rows.map(r=>{
        let cells;
        if(type==='customer'){const sales=customerSales(r),due=sales.reduce((sum,s)=>sum+receiptTotals(s).remaining,0);cells=[esc(r.name),esc(r.phone||'—'),esc(r.email||'—'),esc(r.address||'—'),sales.length,cash(due/100),actions(type,r.id)];}
        if(type==='supplier'){const bills=supplierPurchases(r),due=bills.reduce((sum,p)=>sum+receiptTotals(p,'purchase').remaining,0);cells=[esc(r.name),esc(r.company||'—'),esc(r.phone||'—'),esc(r.email||'—'),bills.length,cash(due/100),actions(type,r.id)];}
        if(type==='expense')cells=[esc(r.title),esc(expenseLabels[r.category]||r.category),cash(r.amount),esc(r.date),r.paymentMethod==='electronic'?'إلكتروني':'نقدي',actions(type,r.id)];
        if(type==='employee')cells=[esc(r.name),esc(r.role),esc(r.phone||'—'),cash(r.salary||0),r.status==='inactive'?'غير نشط':'على رأس العمل',actions(type,r.id)];
        return '<tr>'+cells.map(cell=>`<td>${cell}</td>`).join('')+'</tr>';
    }).join(''):`<tr><td colspan="${cols}">لا توجد سجلات مطابقة. يمكنك إضافة سجل من النموذج أعلاه.</td></tr>`;
    const count=$('#'+c.page+'-count');if(count)count.textContent=`${rows.length} من ${list(c.key).length} سجل`;
    if(type==='expense'&&$('#expenses-total'))$('#expenses-total').textContent=money(rows.reduce((sum,r)=>sum+cents(r.amount),0)/100,currency());
}
function resetDirectory(type) {
    const form=$('#'+type+'-form');if(!form)return;
    form.reset();$('#'+type+'-id').value='';
    if($('#'+type+'-date'))$('#'+type+'-date').value=todayString();
    const heading=$('#'+type+'-form-title');if(heading)heading.textContent='إضافة '+configs[type].label;
    const button=form.querySelector('button[type=submit]');button.textContent='حفظ '+configs[type].label;
}
function editDirectory(type,id) {
    const c=configs[type],record=list(c.key).find(r=>same(r.id,id));if(!record)throw new Error('السجل لم يعد موجودًا.');
    $('#'+type+'-id').value=record.id;
    c.fields.forEach(field=>{const key=field.replace(/-([a-z])/g,(_,letter)=>letter.toUpperCase());const el=$('#'+type+'-'+field);if(el)el.value=record[key]??'';});
    const heading=$('#'+type+'-form-title');if(heading)heading.textContent='تعديل '+c.label;
    $('#'+type+'-form button[type=submit]').textContent='حفظ التعديلات';$('#'+type+'-form').scrollIntoView({behavior:'smooth',block:'start'});$('#'+type+'-'+c.fields[0]).focus({preventScroll:true});
}
function saveDirectory(type,form) {
    const c=configs[type];if(!form.reportValidity())return;
    const data={};for(const field of c.fields){const key=field.replace(/-([a-z])/g,(_,l)=>l.toUpperCase());data[key]=value(type+'-'+field);}
    if(c.required.some(field=>!value(type+'-'+field)))throw new Error('يرجى تعبئة الحقول المطلوبة دون مسافات فارغة.');
    if(type==='expense'){if(!validDate(data.date))throw new Error('تاريخ المصروف غير صحيح.');if(cents(data.amount)<1)throw new Error('مبلغ المصروف يجب أن يكون أكبر من صفر.');data.amount=cents(data.amount)/100;if(!expenseLabels[data.category])throw new Error('اختر تصنيف المصروف.');}
    if(type==='employee'){data.salary=cents(data.salary||0)/100;if(data.startDate&&!validDate(data.startDate))throw new Error('تاريخ التعيين غير صحيح.');if(!['active','inactive'].includes(data.status))throw new Error('اختر حالة الموظف.');}
    const records=list(c.key),id=value(type+'-id'),old=id?records.find(r=>same(r.id,id)):null;
    if(id&&!old)throw new Error('السجل لم يعد موجودًا. أعد فتح الصفحة.');
    const record={...old,...data,id:old?.id||createId(),createdAt:old?.createdAt||new Date().toISOString(),updatedAt:new Date().toISOString()};
    const updated=old?records.map(r=>same(r.id,id)?record:r):[...records,record];
    save({[KEY(c.key)]:updated},'تم حفظ '+c.label+' بنجاح.');resetDirectory(type);renderDirectory(type);
}
async function deleteDirectory(type,id) {
    const c=configs[type],records=list(c.key),record=records.find(r=>same(r.id,id));if(!record)return;
    if(type==='customer'&&customerSales(record).length)throw new Error('لا يمكن حذف عميل مرتبط بفواتير بيع؛ يمكنك تعديل بياناته مع بقاء السجل.');
    if(type==='supplier'&&supplierPurchases(record).length)throw new Error('لا يمكن حذف مورد مرتبط بفواتير مشتريات.');
    if(!await confirmAction('حذف '+c.label+' «'+(record.name||record.title)+'»؟'))return;
    const latest=list(c.key);const current=latest.find(r=>same(r.id,id));if(!current)return;
    if((type==='customer'&&customerSales(current).length)||(type==='supplier'&&supplierPurchases(current).length))throw new Error('السجل أصبح مرتبطًا بفاتورة ولا يمكن حذفه.');
    save({[KEY(c.key)]:latest.filter(r=>!same(r.id,id))},'تم حذف '+c.label+'.');if(same(value(type+'-id'),id))resetDirectory(type);renderDirectory(type);
}
function renderCustomerOptions() {
    const select=$('#sale-customer-id');if(!select)return;const current=select.value;
    select.replaceChildren(new Option('عميل نقدي / اسم غير مسجل',''));
    list('customers').forEach(r=>select.add(new Option(`${r.name}${r.phone?' — '+r.phone:''}`,r.id)));
    if([...select.options].some(o=>o.value===current))select.value=current;
}
function renderPurchaseOptions() {
    const suppliers=$('#purchase-supplier'),products=$('#purchase-product');
    if(suppliers){const current=suppliers.value;suppliers.replaceChildren(new Option('اختر المورد',''));list('suppliers').forEach(r=>suppliers.add(new Option(r.name,r.id)));suppliers.value=current;}
    if(products){const current=products.value;products.replaceChildren(new Option('اختر منتجًا',''));list('products').forEach(r=>products.add(new Option(`${r.name} — ${r.code||'بدون رمز'}`,r.id)));products.value=current;}
}
function renderPurchaseItems() {
    const tbody=$('#purchase-items-table');if(!tbody)return;
    tbody.innerHTML=purchaseItems.length?purchaseItems.map((r,i)=>`<tr><td>${esc(r.name)}</td><td>${r.quantity}</td><td>${cash(r.unitCost)}</td><td>${cash(cents(r.unitCost)*r.quantity/100)}</td><td><button type="button" data-remove-purchase-item="${i}">إزالة</button></td></tr>`).join(''):'<tr><td colspan="5">اختر المنتجات والكميات ثم أضفها للفاتورة.</td></tr>';
    const total=purchaseItems.reduce((sum,r)=>sum+cents(r.unitCost)*r.quantity,0);$('#purchase-total').value=(total/100).toFixed(2);
}
function resetPurchase() {
    purchaseItems=[];activePurchase='';const form=$('#purchase-form');if(form)form.reset();if($('#purchase-date'))$('#purchase-date').value=todayString();if($('#purchase-id'))$('#purchase-id').value='';if($('#purchase-form-title'))$('#purchase-form-title').textContent='تسجيل فاتورة مشتريات';renderPurchaseItems();
}
function addPurchaseItem() {
    const product=list('products').find(r=>same(r.id,value('purchase-product')));if(!product)throw new Error('اختر منتجًا موجودًا من دليل المنتجات.');
    const qty=Number(value('purchase-quantity')),cost=cents(value('purchase-unit-cost'));
    if(!Number.isSafeInteger(qty)||qty<1||qty>1000000)throw new Error('كمية الشراء يجب أن تكون عددًا صحيحًا موجبًا.');
    const old=purchaseItems.find(r=>same(r.productId,product.id));
    if(old){if(old.quantity+qty>1000000)throw new Error('الكمية الإجمالية كبيرة جدًا.');if(cents(old.unitCost)!==cost)throw new Error('المنتج موجود بسعر مختلف؛ أزل السطر القديم أو استخدم سعره نفسه.');old.quantity+=qty;}
    else purchaseItems.push({productId:product.id,name:product.name,quantity:qty,unitCost:cost/100});
    renderPurchaseItems();$('#purchase-quantity').value='1';
}
function purchaseAdjustment(old,items) {
    const products=list('products'),deltas=new Map();
    for(const item of old?.items||[])deltas.set(String(item.productId),(deltas.get(String(item.productId))||0)-Number(item.quantity));
    for(const item of items)deltas.set(String(item.productId),(deltas.get(String(item.productId))||0)+Number(item.quantity));
    for(const[id,delta]of deltas){const p=products.find(r=>same(r.id,id));if(!p)throw new Error('أحد منتجات الفاتورة لم يعد موجودًا؛ لا يمكن تعديل أثر المخزون.');if(!Number.isSafeInteger(Number(p.quantity)+delta)||Number(p.quantity)+delta>1000000000)throw new Error('كمية المخزون خارج الحدود المدعومة.');if(Number(p.quantity)+delta<0)throw new Error('لا يمكن تقليل/حذف هذه المشتريات لأن جزءًا من كميتها استُخدم أو بيع.');}
    return products.map(p=>({...p,quantity:Number(p.quantity)+(deltas.get(String(p.id))||0)}));
}
function savePurchase(form) {
    if(!form.reportValidity())return;
    const supplier=list('suppliers').find(r=>same(r.id,value('purchase-supplier')));if(!supplier)throw new Error('اختر موردًا مسجلًا.');
    if(!purchaseItems.length)throw new Error('أضف منتجًا واحدًا على الأقل للمشتريات.');
    if(!validDate(value('purchase-date')))throw new Error('تاريخ الشراء غير صحيح.');
    const records=list('purchases'),id=activePurchase,old=id?records.find(r=>same(r.id,id)):null;if(id&&!old)throw new Error('الفاتورة لم تعد موجودة.');
    const invoice=value('purchase-invoice');if(!invoice)throw new Error('أدخل رقم فاتورة المورد.');
    if(records.some(r=>!same(r.id,id)&&same(r.supplierId,supplier.id)&&String(r.invoice).toLowerCase()===invoice.toLowerCase()))throw new Error('رقم هذه الفاتورة مستخدم لهذا المورد.');
    const total=purchaseItems.reduce((sum,r)=>sum+cents(r.unitCost)*r.quantity,0);if(!Number.isSafeInteger(total)||total>100000000000)throw new Error('إجمالي الفاتورة كبير جدًا.');
    const paid=cents(value('purchase-paid'));
    const collected=old?receiptTotals(old,'purchase').collected:0;
    if(paid+collected>total)throw new Error('المدفوع مع الدفعات المسجلة يتجاوز قيمة الفاتورة.');
    if(old&&collected&& !same(old.supplierId,supplier.id))throw new Error('لا يمكن تغيير مورد فاتورة لها دفعات مسجلة.');
    const record={...old,id:old?.id||createId(),supplierId:supplier.id,supplierName:supplier.name,invoice,date:value('purchase-date'),paymentMethod:value('purchase-payment-method'),items:purchaseItems.map(r=>({...r})),total:total/100,amountPaid:paid/100,initialAmountPaid:paid/100,notes:value('purchase-notes'),createdAt:old?.createdAt||new Date().toISOString(),updatedAt:new Date().toISOString()};
    save({[KEY('purchases')]:old?records.map(r=>same(r.id,id)?record:r):[...records,record],[KEY('products')]:purchaseAdjustment(old,record.items)},'تم حفظ المشتريات وتحديث كميات المخزون.');resetPurchase();renderPurchases();
}
function editPurchase(id) {
    const r=list('purchases').find(r=>same(r.id,id));if(!r)return;
    activePurchase=r.id;purchaseItems=(r.items||[]).map(item=>({...item}));$('#purchase-id').value=r.id;
    for(const [id,v]of Object.entries({'purchase-supplier':r.supplierId,'purchase-date':r.date,'purchase-invoice':r.invoice,'purchase-payment-method':r.paymentMethod||'cash','purchase-paid':r.initialAmountPaid??r.amountPaid??0,'purchase-notes':r.notes||''}))$('#'+id).value=v;
    $('#purchase-form-title').textContent='تعديل فاتورة مشتريات';renderPurchaseItems();$('#purchase-form').scrollIntoView({behavior:'smooth',block:'start'});
}
async function deletePurchase(id) {
    const r=list('purchases').find(r=>same(r.id,id));if(!r)return;
    if(receiptTotals(r,'purchase').collected)throw new Error('ألغِ الدفعات المسجلة على هذه الفاتورة أولًا.');
    const products=purchaseAdjustment(r,[]);
    if(!await confirmAction('حذف الفاتورة وعكس كميات الشراء من المخزون؟'))return;
    const latest=list('purchases').find(p=>same(p.id,id));if(!latest)return;if(receiptTotals(latest,'purchase').collected)throw new Error('أُضيفت دفعات للفاتورة؛ ألغها أولًا.');
    save({[KEY('purchases')]:list('purchases').filter(p=>!same(p.id,id)),[KEY('products')]:purchaseAdjustment(latest,[])},'تم حذف فاتورة المشتريات وعكس كمياتها.');if(same(activePurchase,id))resetPurchase();renderPurchases();
}
function renderPurchases() {
    const tbody=$('#purchases-table');if(!tbody)return;
    const query=value('purchases-search').toLocaleLowerCase('ar'),from=value('purchases-from'),to=value('purchases-to');
    const records=list('purchases').filter(r=>`${r.invoice} ${r.supplierName}`.toLocaleLowerCase('ar').includes(query)&&(!from||r.date>=from)&&(!to||r.date<=to));
    tbody.innerHTML=records.length?records.map(r=>{const t=receiptTotals(r,'purchase');return `<tr><td>${esc(r.invoice)}</td><td>${esc(r.supplierName||'مورد سابق')}</td><td>${esc(r.date)}</td><td>${cash(r.total)}</td><td>${cash(t.paid/100)}</td><td>${cash(t.remaining/100)}</td><td><button type="button" data-edit-purchase="${esc(r.id)}">تعديل</button><button type="button" data-pay-purchase="${esc(r.id)}" ${t.remaining===0?'disabled':''}>تسديد</button><button type="button" data-delete-purchase="${esc(r.id)}">حذف</button></td></tr>`;}).join(''):'<tr><td colspan="7">لا توجد فواتير مشتريات مطابقة.</td></tr>';
    if($('#purchases-due'))$('#purchases-due').textContent=money(records.reduce((sum,r)=>sum+receiptTotals(r,'purchase').remaining,0)/100,currency());
    renderSupplierPayments();
}
function renderDebtOptions() {
    const select=$('#debt-invoice');if(!select)return;const current=select.value;select.replaceChildren(new Option('اختر فاتورة عليها مبلغ متبقٍ',''));
    list('sales').filter(s=>receiptTotals(s).remaining>0).forEach(s=>select.add(new Option(`${s.invoice||s.id} — ${s.customerName||s.customer||'عميل'} — ${money(receiptTotals(s).remaining/100,currency())}`,s.id)));if([...select.options].some(o=>o.value===current))select.value=current;
    const sale=list('sales').find(s=>same(s.id,select.value));if($('#debt-customer'))$('#debt-customer').value=sale?.customerName||sale?.customer||'';
}
function renderDebts() {
    if(!$('#debts-table'))return;
    const query=value('debts-search').toLocaleLowerCase('ar'),status=value('debts-status');
    const debts=list('sales').filter(s=>{const t=receiptTotals(s);return t.initial<t.total;});
    const rows=debts.filter(s=>`${s.invoice||s.id} ${s.customerName||s.customer}`.toLocaleLowerCase('ar').includes(query)&&(!status||(status==='open'?receiptTotals(s).remaining>0:receiptTotals(s).remaining===0)));
    let original=0,paid=0,remaining=0;for(const s of debts){const t=receiptTotals(s);original+=t.total-t.initial;paid+=t.collected;remaining+=t.remaining;}
    $('#debts-total').textContent=money(original/100,currency());$('#debts-paid').textContent=money(paid/100,currency());$('#debts-remaining').textContent=money(remaining/100,currency());
    $('#debts-table').innerHTML=rows.length?rows.map(s=>{const t=receiptTotals(s);return `<tr><td>${esc(s.customerName||s.customer||'عميل')}</td><td>${esc(s.invoice||s.id)}</td><td>${cash(s.total)}</td><td>${cash(t.paid/100)}</td><td>${cash(t.remaining/100)}</td><td>${esc(s.date)}</td></tr>`;}).join(''):'<tr><td colspan="6">لا توجد ديون تطابق البحث.</td></tr>';
    renderDebtOptions();
    const receipts=list('debt_payments').filter(p=>{const s=list('sales').find(s=>same(s.id,p.saleId));return `${s?.invoice||''} ${s?.customerName||''}`.toLocaleLowerCase('ar').includes(query);});
    $('#debt-payments-table').innerHTML=receipts.length?receipts.map(p=>{const sale=list('sales').find(s=>same(s.id,p.saleId));return `<tr><td>${esc(sale?.invoice||p.saleId)}</td><td>${cash(p.amount)}</td><td>${esc(p.date)}</td><td>${esc(p.notes||'—')}</td><td><button type="button" data-cancel-debt-payment="${esc(p.id)}">إلغاء الدفعة</button></td></tr>`;}).join(''):'<tr><td colspan="5">لم تُسجّل دفعات تحصيل بعد.</td></tr>';
    const badge=$('#debts-nav-count');if(badge){badge.textContent=debts.filter(s=>receiptTotals(s).remaining>0).length;badge.hidden=badge.textContent==='0';}
}
function saveDebtPayment(form) {
    if(!form.reportValidity())return;
    const sale=list('sales').find(s=>same(s.id,value('debt-invoice')));if(!sale)throw new Error('اختر فاتورة بيع مسجلة.');
    const amount=cents(value('debt-payment-amount'));if(amount<1||amount>receiptTotals(sale).remaining)throw new Error('الدفعة يجب أن تكون أكبر من صفر ولا تتجاوز المبلغ المتبقي.');
    const date=value('debt-payment-date');if(!validDate(date))throw new Error('تاريخ الدفع غير صحيح.');
    const record={id:createId(),saleId:sale.id,amount:amount/100,date,notes:value('debt-payment-notes'),createdAt:new Date().toISOString()};
    save({[KEY('debt_payments')]:[...list('debt_payments'),record]},'تم تسجيل التحصيل وتحديث الرصيد.');form.reset();$('#debt-payment-date').value=todayString();renderDebts();
}
function renderSupplierPayments() {
    const tbody=$('#supplier-payments-table');if(!tbody)return;
    const payments=list('supplier_payments');tbody.innerHTML=payments.length?payments.map(p=>{const bill=list('purchases').find(r=>same(r.id,p.purchaseId));return `<tr><td>${esc(bill?.invoice||p.purchaseId)}</td><td>${cash(p.amount)}</td><td>${esc(p.date)}</td><td>${esc(p.notes||'—')}</td><td><button type="button" data-cancel-supplier-payment="${esc(p.id)}">إلغاء الدفعة</button></td></tr>`;}).join(''):'<tr><td colspan="5">لا توجد دفعات موردين مسجلة.</td></tr>';
}
function openSupplierPayment(id) {
    const r=list('purchases').find(r=>same(r.id,id));if(!r)return;const form=$('#supplier-payment-form');form.reset();$('#supplier-payment-purchase').value=r.id;$('#supplier-payment-date').value=todayString();$('#supplier-payment-invoice').textContent=`${r.invoice} — ${r.supplierName} — المتبقي ${money(receiptTotals(r,'purchase').remaining/100,currency())}`;$('#supplier-payment-amount').max=receiptTotals(r,'purchase').remaining/100;$('#supplier-payment-dialog').showModal();
}
function saveSupplierPayment(form) {
    if(!form.reportValidity())return;
    const bill=list('purchases').find(r=>same(r.id,value('supplier-payment-purchase')));if(!bill)throw new Error('الفاتورة غير موجودة.');
    const amount=cents(value('supplier-payment-amount'));if(amount<1||amount>receiptTotals(bill,'purchase').remaining)throw new Error('الدفعة تتجاوز المتبقي أو غير صحيحة.');
    const date=value('supplier-payment-date');if(!validDate(date))throw new Error('تاريخ الدفعة غير صحيح.');
    save({[KEY('supplier_payments')]:[...list('supplier_payments'),{id:createId(),purchaseId:bill.id,amount:amount/100,date,notes:value('supplier-payment-notes'),createdAt:new Date().toISOString()}]},'تم تسجيل دفعة المورد.');$('#supplier-payment-dialog').close();renderPurchases();
}
async function cancelPayment(type,id) {
    const key=type==='debt'?'debt_payments':'supplier_payments';if(!list(key).some(r=>same(r.id,id)))return;
    if(!await confirmAction('إلغاء هذه الدفعة وإعادة المبلغ إلى الرصيد المستحق؟'))return;
    save({[KEY(key)]:list(key).filter(r=>!same(r.id,id))},'تم إلغاء الدفعة وتحديث الرصيد.');renderDebts();renderPurchases();
}
function renderSettings() {
    if(!$('#settings-form'))return;
    const settings=loadData(KEY('settings'),{}),profile=loadData(KEY('profile'),{});
    $('#settings-store-name').value=profile.storeName||settings.storeName||'';$('#settings-currency').value=currency();$('#settings-language').value='ar';$('#settings-low-stock').value=settings.lowStock??5;
}
function saveSettings(form) {
    if(!form.reportValidity())return;
    const name=value('settings-store-name'),curr=value('settings-currency'),threshold=Number(value('settings-low-stock'));
    if(!name)throw new Error('أدخل اسم المتجر.');if(!['₪','$','د.أ','ر.س'].includes(curr))throw new Error('اختر عملة مدعومة.');if(!Number.isSafeInteger(threshold)||threshold<0||threshold>1000000)throw new Error('حد تنبيه المخزون يجب أن يكون عددًا صحيحًا غير سالب.');
    const settings={...loadData(KEY('settings'),{}),storeName:name,currency:curr,language:'ar',lowStock:threshold};const profile=loadData(KEY('profile'),null);const changes={[KEY('settings')]:settings,[KEY('currency')]:curr};if($('#settings-apply-threshold')?.checked)changes[KEY('products')]=list('products').map(p=>({...p,minQuantity:threshold}));if(profile)changes[KEY('profile')]={...profile,storeName:name};
    save(changes,'تم حفظ الإعدادات. العملة تسمية للمبالغ وليست تحويل أسعار.');if(profile)updateProfileUI();
    const status=$('#settings-status');if(status)status.textContent='تم الحفظ بنجاح. حد التنبيه الافتراضي يُستخدم للمنتجات التي ليس لها حد خاص.';
}
function downloadBackup() {
    const keys=['profile','products','sales','customers','suppliers','purchases','expenses','employees','debt_payments','supplier_payments','settings'];
    const data={};for(const key of keys)data[KEY(key)]=loadData(KEY(key),key==='profile'?null:key==='settings'?{}:[]);data[KEY('currency')]=currency();
    const file=new Blob([JSON.stringify({format:'SmartStore-local-backup',version:1,exportedAt:new Date().toISOString(),data},null,2)],{type:'application/json'});const url=URL.createObjectURL(file);const link=document.createElement('a');link.href=url;link.download='SmartStore-backup-'+todayString()+'.json';link.click();setTimeout(()=>URL.revokeObjectURL(url),1000);notify('تم تصدير النسخة الاحتياطية. احتفظ بها في مكان خاص لأنها تتضمن بيانات الحساب.');
}
async function handleClick(event) {
    const target=event.target;
    for(const type of Object.keys(configs))if(target.closest('#add-'+type+'-btn')){resetDirectory(type);$('#'+type+'-'+configs[type].fields[0]).focus();return;}
    const edit=target.closest('[data-edit-record]');if(edit){editDirectory(edit.dataset.editRecord,edit.dataset.recordId);return;}
    const del=target.closest('[data-delete-record]');if(del){await deleteDirectory(del.dataset.deleteRecord,del.dataset.recordId);return;}
    if(target.closest('#add-purchase-item-btn')){addPurchaseItem();return;}
    const remove=target.closest('[data-remove-purchase-item]');if(remove){purchaseItems.splice(Number(remove.dataset.removePurchaseItem),1);renderPurchaseItems();return;}
    if(target.closest('#new-purchase-btn,#reset-purchase-btn')){resetPurchase();return;}
    for(const [attribute,fn]of [['data-edit-purchase',editPurchase],['data-delete-purchase',deletePurchase],['data-pay-purchase',openSupplierPayment]]){const button=target.closest('['+attribute+']');if(button){await fn(button.getAttribute(attribute));return;}}
    const debt=target.closest('[data-cancel-debt-payment]');if(debt)await cancelPayment('debt',debt.dataset.cancelDebtPayment);
    const payment=target.closest('[data-cancel-supplier-payment]');if(payment)await cancelPayment('supplier',payment.dataset.cancelSupplierPayment);
    if(target.closest('#close-supplier-payment'))$('#supplier-payment-dialog').close();
    if(target.closest('#download-backup'))downloadBackup();
}
function renderAll() {
    Object.keys(configs).forEach(renderDirectory);renderPurchases();renderDebts();renderCustomerOptions();
    const badge=$('#debts-nav-count');if(badge){const count=list('sales').filter(s=>receiptTotals(s).remaining>0).length;badge.textContent=count;badge.hidden=!count;}
}
export function initializeOperations() {
    document.addEventListener('submit',event=>{
        const type=Object.keys(configs).find(t=>event.target.id===t+'-form');
        const handlers={'purchase-form':savePurchase,'debt-payment-form':saveDebtPayment,'supplier-payment-form':saveSupplierPayment,'settings-form':saveSettings};
        if(!type&&!handlers[event.target.id])return;event.preventDefault();
        try{if(type)saveDirectory(type,event.target);else handlers[event.target.id](event.target);}catch(error){notify(error.message,'error');}
    });
    document.addEventListener('click',async event=>{try{await handleClick(event);}catch(error){notify(error.message,'error');}});
    document.addEventListener('input',event=>{if(event.target.closest('#page-container'))try{renderAll();}catch(error){notify(error.message,'error');}});
    document.addEventListener('change',event=>{
        try{
            if(event.target.id==='debt-invoice'){const sale=list('sales').find(s=>same(s.id,event.target.value));$('#debt-customer').value=sale?.customerName||sale?.customer||'';}
            if(event.target.id==='sale-customer-id'){const c=list('customers').find(r=>same(r.id,event.target.value));$('#sale-customer').value=c?.name||'';$('#sale-customer').readOnly=Boolean(c);}
            if(event.target.id==='purchase-product'){const p=list('products').find(p=>same(p.id,event.target.value));if(p)$('#purchase-unit-cost').value=Number(p.buyPrice||0).toFixed(2);}
            if(event.target.matches('#employees-status-filter,#expenses-category-filter,#debts-status'))renderAll();
        }catch(error){notify(error.message,'error');}
    });
    document.addEventListener('reset',event=>{const type=Object.keys(configs).find(t=>event.target.id===t+'-form');if(event.target.id==='product-form')setTimeout(()=>{if($('#product-min-quantity'))$('#product-min-quantity').value=loadData(KEY('settings'),{}).lowStock??5;},0);if(event.target.id==='product-form'){if($('#product-form-title'))$('#product-form-title').textContent='إضافة منتج جديد';event.target.querySelector('button[type=submit]').textContent='حفظ المنتج';}if(type){$('#'+type+'-id').value='';const heading=$('#'+type+'-form-title');if(heading)heading.textContent='إضافة '+configs[type].label;event.target.querySelector('button[type=submit]').textContent='حفظ '+configs[type].label;setTimeout(()=>{if($('#'+type+'-date'))$('#'+type+'-date').value=todayString();},0);}});
    window.addEventListener('smartstore:page-loaded',event=>{
        try{
            if(event.detail.page==='purchases'){resetPurchase();renderPurchaseOptions();}
            if(event.detail.page==='settings')renderSettings();
            if(event.detail.page==='products'&&$('#product-min-quantity'))$('#product-min-quantity').value=loadData(KEY('settings'),{}).lowStock??5;
            for(const field of ['expense-date','purchase-date','debt-payment-date'])if($('#'+field))$('#'+field).value=todayString();
            renderAll();
            if(!recoverPendingTransaction())notify('تعذر استرداد عملية حفظ سابقة. لا تمسح بيانات المتصفح، وتحقق من سماح التخزين.','error');
        }catch(error){notify(error.message,'error');}
    });
    window.addEventListener('smartstore:data-updated',()=>{try{renderAll();}catch(error){notify(error.message,'error');}});
}
