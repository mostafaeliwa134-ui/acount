
"use strict";

import { notify } from "./feedback.js";
import { getProfile } from "./auth.js";
import { saveData } from "./storage.js";

const $ = (selector) => document.querySelector(selector);

// تحديث بيانات الملف الشخصي في الواجهة
export function updateProfileUI(profile = getProfile()) {
    if (!profile) {
        return;
    }

    const ownerName = profile.ownerName || profile.name || "صاحب المتجر";
    const storeName = profile.storeName || "متجري";
    const email = profile.email || "";

    const initials = ownerName
        .trim()
        .split(/\s+/)
        .slice(0, 2)
        .map((part) => part.charAt(0))
        .join("")
        .toUpperCase() || "م";

    const elements = [
        ["#profile-name", ownerName],
        ["#dropdown-profile-name", ownerName],
        ["#dropdown-profile-email", email],
        ["#sidebar-store-name", storeName],
        ["#profile-page-owner-name", ownerName],
        ["#profile-page-store-name", storeName],
        ["#profile-page-email", email || "—"],
        ["#profile-page-phone", profile.phone || "—"]
    ];

    elements.forEach(([selector, value]) => {
        const element = $(selector);

        if (element) {
            element.textContent = value;
        }
    });

    const avatar = $("#profile-avatar");

    if (avatar) {
        avatar.textContent = initials;
    }

    const fields = {
        "#profile-owner-name": ownerName,
        "#profile-store-name": storeName,
        "#profile-email": email,
        "#profile-phone": profile.phone || ""
    };
    Object.entries(fields).forEach(([selector, value]) => {
        const input = $(selector);
        if (input) input.value = value;
    });
}

function showProfileMessage(message) {
    const status = $("#profile-save-status");
    if (status) { status.textContent = message; status.dataset.type = /تعذر|يرجى/.test(message) ? "error" : "success"; }
}

function saveProfile(event) {
    if (event.target.id !== "profile-form") return;
    event.preventDefault();

    const existing = getProfile();
    if (!existing) {
        showProfileMessage("تعذر العثور على الحساب. سجّل الدخول مجددًا.");
        return;
    }

    const updated = {
        ...existing,
        ownerName: $("#profile-owner-name").value.trim(),
        storeName: $("#profile-store-name").value.trim(),
        email: $("#profile-email").value.trim(),
        phone: $("#profile-phone").value.trim()
    };

    if (!updated.ownerName || !updated.storeName || !updated.email) {
        showProfileMessage("يرجى تعبئة اسم صاحب المتجر واسم المتجر والبريد الإلكتروني.");
        return;
    }
    if (!event.target.reportValidity()) return;

    if (!saveData("smartstore_profile", updated)) {
        showProfileMessage("تعذر حفظ البيانات. حاول مجددًا.");
        return;
    }

    updateProfileUI(updated);
    showProfileMessage("تم حفظ بيانات الحساب والمتجر بنجاح.");
    notify("تم تحديث معلومات الحساب والمتجر.");
}

// تجهيز واجهة الملف الشخصي
export function initializeProfile() {
    updateProfileUI();
    document.addEventListener("submit", saveProfile);

    window.addEventListener("smartstore:page-loaded", (event) => {
        if (event.detail?.page === "profile") updateProfileUI();
    });

    window.addEventListener("smartstore:login", (event) => {
        updateProfileUI(event.detail?.profile);
    });
}
